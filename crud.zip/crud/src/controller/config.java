/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author yachya
 */
public class config {
    private static Connection sql;
    public static Connection configDB()throws SQLException{
        String url="jdbc:mysql://localhost:3306/db_oop", user ="root", pass="";
        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            sql = DriverManager.getConnection(url,user,pass);
        } catch (SQLException ex) {
            System.err.println("Koneksi Gagal"+ex.getMessage());
        }
        return sql;
        
    }
    
}
